Config = {}

Config.Colors = {
    ["default"] = 16711680,
}

-- WEBHOOKS LOGS
Config.Webhooks = {
    -- Chat
    ["DepositSafe"] = "WEBHOOKS HERE",
    ["RemoveSafe"] = "WEBHOOKS HERE",
    ["DepositCarTrunk"] = "WEBHOOKS HERE",
    ["RemoveCarTrunk"] = "WEBHOOKS HERE",
    ["DepositGlovebox"] = "WEBHOOKS HERE",
    ["RemoveGlovebox"] = "WEBHOOKS HERE",
    ["DepositPlayer"] = "WEBHOOKS HERE",
    ["RobberyPlayer"] = "WEBHOOKS HERE",
    ["DepositFloor"] = "WEBHOOKS HERE",
    ["RemoveFloor"] = "WEBHOOKS HERE",
    ["GivePlayer"] = "WEBHOOKS HERE",
    ["GiveStaff"] = "WEBHOOKS HERE",
    ["DowngradeGun"] = "WEBHOOKS HERE",
    ["UpgradeGun"] = "WEBHOOKS HERE",
    ["ShoppingStore"] = "WEBHOOKS HERE",
}

-- LOG TITLES 
Config.DepositSafe     = '-_- Deposited in the safe -_-'
Config.RemoveSafe      = '-_- Removed from safe -_-'
Config.DepositCarTrunk = '-_- Deposit Car Trunk -_-'
Config.RemoveCarTrunk  = '-_- Remove Car Trunk -_-'
Config.DepositGlovebox = '-_- Deposit Glovebox -_-'
Config.RemoveGlovebox  = '-_- Remove Glovebox -_-'
Config.DepositPlayer   = '-_- Deposit Player -_-'
Config.RobberyPlayer   = '-_- Robbery Player -_-'
Config.DepositFloor    = '-_- Deposit Floor -_-'
Config.RemoveFloor     = '-_- Remove Floor -_-'
Config.GivePlayer      = '-_- Give Player -_-'
Config.GiveStaff       = '-_- Give Staff -_-'
Config.DowngradeGun    = '-_- Downgrade Gun -_-'
Config.UpgradeGun      = '-_- Upgrade Gun -_-'
Config.ShoppingStore   = '-_- Shopping Store -_-'